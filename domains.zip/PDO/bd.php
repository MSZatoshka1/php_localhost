<?
	$host = '127.0.0.1';
	$dbname = 'PDO';
	$user = 'root';
	$pass = '';
	try {
	 	$bd = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
	 	$bd->exec("SET NAMES UTF8");
	 	$bd->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );  	
	 } 
	 catch (Exception $e) {
	 	echo $e->getMessage(); 
	 }
?>