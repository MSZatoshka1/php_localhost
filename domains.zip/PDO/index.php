<?
	include "bd.php";
?>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" href="main.css">
	</head>
	<body>
		<div class="conteiner">
			<?
				$STH_get = $bd ->query("SELECT * FROM klient");
				$STH_get -> setFetchMode(PDO::FETCH_OBJ); 
				while($row = $STH_get -> fetch()){	
			?> 
			<div class="block">
				<div class="linia">
					<h1 class="name"> <? echo "Имя огранизации - {$row->name}"; ?></h1>
					<h1 class="adres"><? echo "Адрес огранизации - {$row->adrec}"; ?></h2>
				</div>
				<p class="text"><? echo $row->text; ?></p>
			</div>
			<? } ?>
			<form action="" id='form_klienta' method="POST">
				<input type="text" name ='name' placeholder="Введите ваше имя">
				<input type="text" name ='adrec' placeholder="Введите ваш адрес">
				<textarea name ='text' placeholder="введите сообщение"></textarea>
				<button name='otprabka'>Отправить</button>
			</form>
		</div>
	</body>
</html>
<?
	 if(isset($_POST['otprabka'])){
	 	$name = trim($_POST['name']);
	 	$adrec = trim($_POST['adrec']);
	 	$text = trim($_POST['text']);
	 	// strip_tags - удаляет с текста все теги
	 	$name = strip_tags($name);  
	 	$adrec = htmlspecialchars($adrec); 
	 	$text = htmlspecialchars($text);   

	 	//  if($name != '' &&  $adrec != '' &&  $text != ''){
	 	//  	 $STH = $bd->prepare("INSERT INTO  klient (name,adrec,text) values  (?,?,?)");
	 	//  	 $STH->bindParam(1, $name);  
			// $STH->bindParam(2, $adrec);  
			// $STH->bindParam(3, $text);
			//  $STH->execute(); 
	 	//  }else{
	 	//  	echo "Вы не указали все данные";	 
	 	//  }
	 	if($name != '' &&  $adrec != '' &&  $text != ''){
	 	 	 $STH = $bd->prepare("INSERT INTO  klient (name,adrec,text) values  (:name,:adrec,:text)");
	 	 	 $parametr = ['name' => $name,'adrec' => $adrec,'text' => $text];
			 $STH->execute($parametr); 
	 	 }else{
	 	 	echo "Вы не указали все данные";	 
	 	 }
	 }
	  
?>