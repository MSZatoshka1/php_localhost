<?
  if(extension_loaded('sockets')) echo "Работает";
  else echo "Не работает";
?>