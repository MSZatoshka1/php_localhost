<?
	$host = '127.0.0.1';
	$dbname = '123';
	$user = 'root';
	$pass = '';
	try {
	 	$BD = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
	 	$BD->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );  	
	 } 
	 catch (Exception $e) {
	 	echo $e->getMessage(); 
	 }
?>