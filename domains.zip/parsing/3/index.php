<!DOCTYPE html>
<html lang="ru">
	<head>
		<link rel="stylesheet" href="css/main.css">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width">
        <meta name="keywords" content=" Ключевые слова">
        <meta name="description" content="краткое описание">
    </head>
    <body>
    	 <?
			include_once 'phpQuery/phpQuery.php';
			include_once 'function.php';
			include_once 'bd.php';
			$url = 'http://theory.phphtml.net/exercises/advanced/php/parsing/poetapnyj-parsing-i-metod-pauka/1/';
			$a = setCurl($url);
			$pq = phpQuery::newDocument($a); //создание phpQuery объекта
			$elem = $pq -> find('#menu a');
			foreach ($elem as $value) {
				$link = pq($value);
				$text[] = $link->attr('href');				  
			}
			foreach ($text as $key => $value) {
				$urls = "{$url}{$value}";
				$a = setCurl($urls);
				$pq = phpQuery::newDocument($a);
				$content = $pq->find('#content')->text();
				$title = $pq->find('title')->text();
				$STH = $BD->prepare("INSERT INTO parsion_1 (url,content,title) values (?,?,?)");
				$STH -> bindParam(1, $urls);  
				$STH -> bindParam(2, $content);  
				$STH -> bindParam(3, $title);
				$STH->execute(); 
			} 
		?>
    </body>
</html>
 
