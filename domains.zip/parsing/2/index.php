<!DOCTYPE html>
<html lang="ru">
	<head>
		<link rel="stylesheet" href="css/main.css">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width">
        <meta name="keywords" content=" Ключевые слова">
        <meta name="description" content="краткое описание">
        <title>Заголовок сайта</title>
    </head>
    <body>
    	 <?
			include_once 'phpQuery/phpQuery.php';
			include_once 'function.php';
			$a = setCurl('https://dominos.by/ru/Pizza/');
			$pq = phpQuery::newDocument($a); //создание phpQuery объекта
			$elem = $pq -> find('.product_item > p >a');
			foreach ($elem as $value) {
				$link = pq($value);
				$text = $link->text();
				$href = $link->attr('href');
				echo "<div><a href = 'https://dominos.by{$href}'>{$text}</a></div>";	 
			}
			 	 
		?>
    </body>
</html>
 
