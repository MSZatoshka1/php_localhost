<?
	function setCurl($url,$check = false, $key = '',$val = ''){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url); // указываем ссылку парсинга
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // сохранить в переменную
		 curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
		if($check === true){
			curl_setopt($curl, CURLOPT_POSTFIELDS,"{$key}={$val}");
		}
		$result = curl_exec($curl);
		if ($result === false) {
			echo "Ошибка CURL: " . curl_error($curl);
		} else{
			return $result;
		}
	}
	function foreach_parsing($elem,$attr){
		foreach ($elem as $value) {
			$link  = pq($value);
			$return[] = $link->attr($attr); 
		} 
		return $return;
	}
	function foreach_parsing_text($elem){
		foreach ($elem as $value) {
			$link  = pq($value);
			$return = $link->text(); 
		}
		return $return;
	}
?>