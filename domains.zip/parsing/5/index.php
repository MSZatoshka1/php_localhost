<!DOCTYPE html>
<html lang="ru">
	<head>
		<link rel="stylesheet" href="css/main.css">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width">
        <meta name="keywords" content=" Ключевые слова">
        <meta name="description" content="краткое описание">
    </head>
    <body>
    	 <?
			include_once 'phpQuery/phpQuery.php';
			include_once 'function.php';
			include_once 'bd.php';
			$url = 'http://theory.phphtml.net/exercises/advanced/php/parsing/avtomaticheskaya-otpravka-form-na-php-s-pomoshchyu-curl/1/1.php';
			$array = [2,12,5,21,123];
			$array1 = [
				['name' =>'Кирилл', 'message'=>'текст'] , 
				['name' =>'Макс', 'message'=>'текст']
			];
			$key = 'num';

			function parsing_POST($url,$select,$array, $key = null){	
				foreach ($array as $key1 => $value) {
					$a = setCurl($url,true, $key,$value);
					$pq = phpQuery::newDocument($a); //создание phpQuery объекта
					$p = $pq->find($select);
					$z[] = foreach_parsing_text($p);
				}
				return $z;	 
			}
 
		?>
    </body>
</html>
 
