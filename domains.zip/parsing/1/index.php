<?
	include_once 'phpQuery/phpQuery.php';
	include_once 'function.php';
	$a = setCurl('http://theory.phphtml.net');
	$pq = phpQuery::newDocument($a); //создание phpQuery объекта
	$elem = $pq->find('.dropdown-menu > li >a');
 	foreach ($elem as $value) {
 		$pqLink = pq($value);	
 		$text = $pqLink->text();
 		$href = $pqLink->attr('href');
 		$elem  = $text;
 		echo 
 		"<div class = 'block'>
 			<a href = 'http://theory.phphtml.net{$href}'>
 				{$text}
 			</a>
 		</div>";		 	 
 	}	 	 
?>
