<?
	include_once 'phpQuery/phpQuery.php';
	include_once 'function.php';
	$a  = setCurl('http://theory.phphtml.net/exercises/advanced/php/parsing/rabota-s-bibliotekoj-phpquery-v-php/2/1.php');
	$pq = phpQuery::newDocument($a);
	$img = $pq->remove('img');
	$text = $pq->html(); 
	echo $text;
?>