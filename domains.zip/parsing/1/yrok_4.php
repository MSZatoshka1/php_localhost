<?
	include_once 'phpQuery/phpQuery.php';
	include_once 'function.php';
	$a = setCurl('http://theory.phphtml.net/exercises/advanced/php/parsing/rabota-s-bibliotekoj-phpquery-v-php/1/1.php');
	$pq = phpQuery::newDocument($a);
	// var_dump($pq);
	$content_elem = $pq->find('#content');
	$footer_elem = $pq->find('#footer');
	$sidebar_elem = $pq->find('.sidebar');
	$content_html = $content_elem->html();
	$p = $pq->find('p');
	$a = $pq->find('a');
	$a_www = $pq->find('a.www');
	$p_www = $pq->find('p.www');
	$content_a = $pq->find('#content >a');
	$content_a_www = $pq->find('#content >a.www');
	$pag = $pq-> find('.pag  a');
	echo "{$pag} <br> " ;


	foreach ($a as $value) {
		$pqLink = pq($value);
		$text = $pqLink-> text();
		$href = $pqLink-> attr('href');
		if(isset($href)){
			echo "<a href={$href}> {$text} </a><br>";
		}
	}
	// echo " {$content_html}{$footer_elem}{$sidebar_elem}";
?>