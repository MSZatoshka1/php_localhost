<?
	include_once 'phpQuery/phpQuery.php';
	include_once 'function.php';
	$a  = setCurl('dominos.by');
	$pq = phpQuery::newDocument($a);
?>