<!DOCTYPE html>
<html lang="ru">
	<head>
		<link rel="stylesheet" href="css/main.css">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width">
        <meta name="keywords" content=" Ключевые слова">
        <meta name="description" content="краткое описание">
    </head>
    <body>
    	 <?
			include_once 'phpQuery/phpQuery.php';
			include_once 'function.php';
			include_once 'bd.php';
			$url = 'https://rybalku.ru';
			$a = setCurl($url);
			$pq = phpQuery::newDocument($a); //создание phpQuery объекта
			// Вводные данные
			$elem1 = $pq -> find('table:first a img');
			$attr1 = 'src';
			$elem2 = $pq -> find('table:first tr td a:not(".aImg")');
			$elem3 = $pq -> find('table:first tr td:last-child');
			// --------------
			//  Вызов функции
			$src = foreach_parsing($elem1 ,$attr1);
			$name = foreach_parsing_text($elem2);
			$content = foreach_parsing_text($elem3);
			$name[26] = $name[28];
			unset($name[27]);// сайт говно верстка или я не смог в селекторы.
			unset($name[28]); 
			// --------------
			foreach ($src as $key => $value) {
				$image_name = basename($value); // узнать имя файла
				file_put_contents("img/{$image_name}", file_get_contents("{$value}"),FILE_APPEND);
				$srcs = "img/{$image_name}";
				$STH = $BD->prepare("INSERT INTO parsion_2 (name,content,img) values (?,?,?)");
				$STH -> bindParam(1, $name[$key]);  
				$STH -> bindParam(2, $content[$key]);  
				$STH -> bindParam(3, $srcs);
				$STH->execute(); 
			}
		?>
    </body>
</html>
 
