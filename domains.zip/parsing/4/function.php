<?
	function setCurl($url){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url); // указываем ссылку парсинга
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // сохранить в переменную
		$result = curl_exec($curl);
		if ($result === false) {
			echo "Ошибка CURL: " . curl_error($curl);
		} else{
			return $result;
		}
	}
	function foreach_parsing($elem,$attr){
		foreach ($elem as $value) {
			$link  = pq($value);
			$return[] = $link->attr($attr); 
		} 
		return $return;
	}
	function foreach_parsing_text($elem){
		foreach ($elem as $value) {
			$link  = pq($value);
			$return[] = $link->text(); 
		}
		return $return;
	}
?>