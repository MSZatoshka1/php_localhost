<!DOCTYPE html>
<html lang="	">
	<head>
		 <meta charset="UTF-8">
		<meta name="viewport" content="width=device-width">
        <meta name="keywords" content=" Ключевые слова">
        <meta name="description" content="краткое описание">
        <title>Заголовок сайта</title>
       <script src="jquery.js"></script>
    </head>
    <body>
    	<header>
    		<div class="conteiner">
    			<div id="logo">
    				<img src="" alt="">
    			</div>
    			<!-- logo -->
    			<nav>
     				<ul>
     					
     				</ul>
     			</nav>
     			<!-- nav -->
     		</div>
     		<!-- conteiner -->
    	</header>
    	<!--  -->
    	<section>
     				
     	</section>
     	<!--  -->
     	<footer>
     		<div class="conteiner">
     	
     		</div>
     		<!-- conteiner -->
     	</footer>
     	<!--  -->
     	<script src="script.js"></script>
    </body>
</html>