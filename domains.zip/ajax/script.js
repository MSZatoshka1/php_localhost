$.ajax({
	url: 'fuction.php',
	type: 'GET',
	// dataType: 'default: Intelligent Guess (Other values: xml, json, script, or html)',
	data: {a:3, b:5},
})
.done(function(data) {
	console.log(data);
})
.fail(function() {
	// console.log("error");
})
.always(function() {
	console.log("complete");
});
