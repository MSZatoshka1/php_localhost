<?
	$a = $_GET['a'];
	$b = $_GET['b'];
	$sum = $a + $b;
	echo "Сумма переменных = {$sum}";
?>